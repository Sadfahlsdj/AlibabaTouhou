import pygame
import pygame.gfxdraw
import sys
import os
import math
import random
import numpy
from pygame.locals import *
from bullet import *
from player import *

pygame.init()
pygame.font.init()

"""TODO:
attack idea: shots that leave trails that act as walls
"""
fps = 60
wh = 20
ww = 20
xlimit, ylimit = 1200, 960  # make sure to change these if ever changed in main code
h, hm = 100, 20  # hole, holemovement
a10xpos, a10ypos = xlimit/2, ylimit/5 #used for attack 10
a11xpos, a11ypos = xlimit/2, ylimit/5 #used for attack 11
(a12xpos, a12ypos, a12leftx,
 a12lefty, a12rightx, a12righty) = xlimit/2, ylimit/5, 50, ylimit/3, xlimit-50, ylimit/2 #used for attack 12
xvl, yvl, xvr, yvr = 4, 4, -4, 4 #used for attack 12 as well


def Attack0(spawncounter, walls, wall_group):  # random shots
    if spawncounter % int(fps / 5) == 0 and spawncounter >= 0:  # every 10 ticks (0.2 seconds) next wave is spawned, adjust for balance
        # second condition is how bombs prevent bullet spawning
        #spawncounter = 0
        for i in range(11):  # 8 bullets per wave, adjust for balance
            xrandompos = random.randint(0, xlimit - 50)
            yrandompos = 15 + random.randint(-30, 30)
            bu = Bullet(xrandompos, yrandompos, xrandompos, yrandompos, 4, 0, 0, False, False, 0, 0, 0,0, 255, 0, 0)
            walls.append(bu)
            bu.setXVel(random.randint(-1, 1))
            bu.setYVel(4)  # should be 4


def Attack1(spawncounter, walls, wall_group):  # moving safespot
    #print(str(spawncounter % int(fps / 5)))
    #print(str(spawncounter))
    #print("attack1 ongoing")
    size = 10
    """if spawncounter < 250 or spawncounter > 500:
        size = 10
    else:
        size = 1"""
    if spawncounter % int(fps / 5) == 0 and spawncounter >= 0:
        global h
        global hm
        gap = 70  # gap in which to dodge in, change for balance
        for i in range(int(h / 20)):
            xbulletpos = i * 20
            ybulletpos = 0
            bu = Bullet(xbulletpos, ybulletpos, xbulletpos, ybulletpos, size, 0, 0, False, False, 0, 0, 0, 0, 255, 0, 0)
            bu.setXVel(0)
            bu.setYVel(3)

            walls.append(bu)
            # bu.setxvel(0)
            # bu.setyvel(0)
        for i in range(int((h + gap) / 20), xlimit):
            xbulletpos = i * 20
            ybulletpos = 60
            bu = Bullet(xbulletpos, ybulletpos, xbulletpos, ybulletpos, size, 0, 0, False, False, 0, 0, 0, 0, 255, 0, 0)
            bu.setXVel(0)
            bu.setYVel(3)
            walls.append(bu)
            # bu.setxvel(0)
            # bu.setyvel(0)
        h += hm

        if h >= (xlimit - 60):
            hm = -20
        if h <= 60:
            hm = 20


def Attack2(spawncounter, burstcounter, player, walls, wall_group):  # pseudotargeted walls
    playerx = player.getRect().x
    playery = player.getRect().y
    if spawncounter % (int(fps / 4)) == 0 and spawncounter >= 0 and burstcounter % (int(2.5 * fps)) < (int(7 * fps / 4)):
        for i in range(int(xlimit/20)):
            xbulletpos = i * 20
            ybulletpos = 0
            bu = Bullet(xbulletpos, ybulletpos, xbulletpos, ybulletpos, 10, 0, 0, False, False, 0, 0, 0, 0, 255, 0, 0)
            bu.setXDiff(playerx - xbulletpos)
            bu.setYDiff(playery - ybulletpos)
            # bu.setxvel(0)
            # bu.setyvel(0)
            bu.setXVel(bu.getXDiff() / 100.0)
            bu.setYVel(bu.getYDiff() / 100.0)
            walls.append(bu)
            # xdiff = playerx - xbulletpos
            # ydiff - playery - ybulletpos


def Attack3(spawncounter, walls, wall_group):  # circular bursts of explosions
    if spawncounter % int(2.5 * fps) == 0 and spawncounter >= 0:
        for i in range(int(xlimit/40)):
            for j in range(17):
                xbulletpos = i * 40
                ybulletpos = 200
                bu = Bullet(xbulletpos, ybulletpos, xbulletpos, ybulletpos, 6, 0, 0, False, False, 0, 0, 0,0, 255, 0, 0)
                # if bu.getxvelset == False:
                bu.setXVel(3 * math.sin(math.radians(j * 20)))
                bu.setYVel(3 * math.cos(math.radians(j * 20)))
                bu.setXVelSet(True)
                # print(bu.getyvel())
                walls.append(bu)
                # xdiff = playerx - xbulletpos
                # ydiff - playery - ybulletpos


def Attack4(spawncounter, attack4marker, walls, wall_group):  # flowers; this one may be broken more testing is needed
    if spawncounter % int(fps / 5) == 0 and spawncounter > 0:
        for i in range(4):
            for j in range(5):
                xbulletpos = xlimit / 2
                ybulletpos = ylimit / 2
                bu = Bullet(xbulletpos, ybulletpos, xbulletpos, ybulletpos, 6, 0, 0, False, False, 0, 0, 0, 0, spawncounter % 256,
                            (spawncounter + 50) % 256, (spawncounter + 100) % 256)
                # if bu.getxvelset == False:
                bu.setXVel(3 * math.sin(math.radians((i * 6 + j) * 20) + attack4marker))
                bu.setYVel(3 * math.cos(math.radians((i * 6 + j) * 20) + attack4marker))
                bu.setXVelSet(True)
                # print(bu.getYVel())
                walls.append(bu)
                # xdiff = playerx - xbulletpos
                # ydiff - playery - ybulletpos
        #if attack4marker > 1.8:
            #attack4marker = -1.8
        for i in range(10): #anti safespot techniques
            bu = Bullet(50, i*25, 50, i*25, 30, 0, 0, False, False, 0, 0, 0,0, 255,0, 0)
            bu.setXVel(50)
            bu.setYVel(0)
            walls.append(bu)


def Attack5(spawncounter, walls, wall_group):  # slow shots from all directions
    bulletcount = 6  # number of bullets per wave, change for balance
    sc = int(2 * fps / 5)  # number of ticks between spawns, change for balance
    if spawncounter % sc == 0 and spawncounter > 0:
        for i in range(bulletcount):  # 8 bullets per wave, adjust for balance
            xrandompos = random.randint(0, xlimit)
            yrandompos = 0
            bu = Bullet(xrandompos, yrandompos, xrandompos, yrandompos,6, 0, 0, False, False, 0, 0, 0, 0, 255, 0, 0)
            walls.append(bu)
            bu.setXVel(0)
            bu.setYVel(3)
    if spawncounter % sc == int(sc / 4) and spawncounter > 0:
        for i in range(bulletcount):  # 8 bullets per wave, adjust for balance
            xrandompos = random.randint(0, xlimit)
            yrandompos = ylimit
            bu = Bullet(xrandompos, yrandompos, xrandompos, yrandompos, 6, 0, 0, False, False, 0, 0, 0, 0, 255, 0, 0)
            walls.append(bu)
            bu.setXVel(0)
            bu.setYVel(-3)
    if spawncounter % sc == int(sc / 2) and spawncounter > 0:
        for i in range(bulletcount):  # 8 bullets per wave, adjust for balance
            xrandompos = 30
            yrandompos = random.randint(0, ylimit)
            bu = Bullet(xrandompos, yrandompos, xrandompos, yrandompos, 6, 0, 0, False, False, 0, 0, 0, 0, 0, 0, 255)
            walls.append(bu)
            bu.setXVel(3)
            bu.setYVel(0)
    if spawncounter % sc == int(3 * sc / 4) and spawncounter > 0:
        for i in range(bulletcount):  # 8 bullets per wave, adjust for balance
            xrandompos = xlimit
            yrandompos = random.randint(0, ylimit)
            bu = Bullet(xrandompos, yrandompos, xrandompos, yrandompos, 6, 0, 0, False, False, 0, 0, 0, 0, 0, 0, 255)
            walls.append(bu)
            bu.setXVel(-3)
            bu.setYVel(0)


def Attack6(spawncounter, walls, wall_group):  # flower shaped bursts
    xpos = random.randint(0, xlimit)
    ypos = random.randint(0, int(ylimit / 3))
    if spawncounter % int(fps / 7) == 0 and spawncounter >= 0:
        r, g, b = random.randint(50, 220), random.randint(50, 220), random.randint(50, 220)
        for i in range(29):
            bu = Bullet(xpos, ypos, xpos, ypos, 6, 0, 0, False, False, 0, 0, 0, 0, r, g, b)
            bu.setXVel(3.5 * math.sin(math.radians((i * 12))))
            bu.setYVel(3.5 * math.cos(math.radians((i * 12))))
            bu.setXVelSet(True)
            walls.append(bu)


def Attack7(spawncounter, walls, player, wall_group):  # flower burst + targeted shots
    xpos = random.randint(0, xlimit)
    ypos = random.randint(0, int(ylimit / 3))
    if spawncounter % int(fps / 6) == 0 and spawncounter >= 0:
        r, g, b = random.randint(50, 220), random.randint(50, 220), random.randint(50, 220)
        for i in range(19):
            bu = Bullet(xpos, ypos, xpos, ypos, 6, 0, 0, False, False, 0, 0,0, 0,  r, g, b)
            bu.setXVel(3 * math.sin(math.radians((i * 18))))
            bu.setYVel(3 * math.cos(math.radians((i * 18))))
            bu.setXVelSet(True)

            walls.append(bu)
    playerx = player.getRect().x
    playery = player.getRect().y
    if spawncounter % int(fps / 12) == 0 and spawncounter >= 0:
        # for i in range(2):
        xbulletpos = (3.5 * spawncounter) % xlimit
        ybulletpos = 50
        bu = Bullet(xbulletpos, ybulletpos, xbulletpos, ybulletpos, 8, 0, 0, False, False, 0, 0, 0, 0, 255, 0, 0)
        bu.setXDiff(playerx - xbulletpos)
        bu.setYDiff(playery - ybulletpos)
        # bu.setxvel(0)
        # bu.setyvel(0)
        bu.setXVel(bu.getXDiff() / 100.0)
        bu.setYVel(bu.getYDiff() / 100.0)
        walls.append(bu)
        # xdiff = playerx - xbulletpos
        # ydiff - playery - ybulletpos
def Attack8(spawncounter, attackduration, walls, wall_group):
    # shots originate in rotating patterns; straight downwards secondary pattern
    xpos = [3 * xlimit/12, 5 * xlimit/12, 7 * xlimit/12, 9 * xlimit/12]
    ypos = [ylimit/4, ylimit/2, ylimit/2, ylimit/4]
    spawndelay = int(fps / 30) #makes shit easier for me
    if spawncounter % spawndelay == 0 and spawncounter >= 0:
        for i in range(3):
            bu = Bullet(xpos[i], ypos[i], xpos[i], ypos[i], 5, 0, 0, False, False, 0, 0, 0, 0, 255, 0, 0)
            bu.setXVel((3 + spawncounter % 3) * math.sin(9 * (math.radians(spawncounter + 90*i))))
            bu.setYVel((3 + spawncounter % 3) * math.cos(9 * (math.radians(spawncounter + 90*i))))
            #print("xvel, yvel:", bu.getXVel(), bu.getYVel())
            bu.setXVelSet(True)
            walls.append(bu)

    if spawncounter % int(2 * fps / 5) == 0 and spawncounter >= 0 and attackduration >= (7 * fps):
        for i in range(5):  # 5 bullets per wave, adjust for balance
            xrandompos = random.randint(0, xlimit)
            yrandompos = 60
            r, g, b = random.randint(50, 220), random.randint(50, 220), random.randint(50, 220)
            bu = Bullet(xrandompos, yrandompos, xrandompos, yrandompos, 5, 0, 0, False, False, 0, 0, 0, 0, r, g, b)
            walls.append(bu)
            bu.setXVel(0)
            bu.setYVel(4)  # should be 4
def Attack9(spawncounter, attackduration, walls, wall_group):
    #WAY TOO HARD NEEDS NERFING
    #bursts of shots that linger for a little
    #lingering & bullet killing is done in main method

    spawnTimeMarker = ((spawncounter // int(fps * 1.5)) + 1) % 8
    #print("spawntimemarker", spawnTimeMarker)
    if spawnTimeMarker < 1:
        spawnTimeMarker = 1
    sm = 6.2 + (spawnTimeMarker % 3) # speedmodifier, change for bullet speed
    if spawncounter % int(fps / 17) == 0:
        xpos = xlimit - (spawnTimeMarker % 8) * xlimit/8
        sm2 = 7 + (xpos % (xlimit/2)) / (xlimit/8)
        ypos = ylimit / 20
        for i in range(7):  # 8 bullets per wave, adjust for balance
            bu = Bullet(xpos, ypos, xpos, ypos, 2, 0, 0, False, False, 0, 0, spawnTimeMarker,
                        0, (spawnTimeMarker % 255), (spawnTimeMarker + 50) % 255, (spawnTimeMarker + 100) % 255)
            b2 = Bullet(xlimit - xpos, ypos, xlimit - xpos, ypos, 2, 0, 0, False, False, 0, 0, spawnTimeMarker,
                        0, (spawnTimeMarker % 255), (spawnTimeMarker + 50) % 255, (spawnTimeMarker + 100) % 255)
            bu.setXVel(random.uniform(-1 * sm2, sm2))
            bu.setYVel(math.sqrt((2 * sm2 ** 2) - bu.getXVel() ** 2))
            b2.setXVel(random.uniform(-1 * sm2, sm2))
            b2.setYVel(math.sqrt((2 * sm2 ** 2) - bu.getXVel() ** 2))
            walls.append(bu)
            walls.append(b2)
            #print("bullet xpos", xpos)

def Attack10(spawncounter, attackduration, walls, wall_group):
    #moving "center" that spawns multiple rings of shots
    #collisions likely broken due to large shot size
    global a10xpos
    global a10ypos
    #xpos = random.randint(0, xlimit)
    #ypos = random.randint(0, int(ylimit / 3))
    if spawncounter % int(fps / 2) == 0 and spawncounter >= 0:
        r, g, b = random.randint(50, 220), random.randint(50, 220), random.randint(50, 220)
        for i in range(29):
            bu = Bullet(a10xpos, a10ypos, a10xpos, a10ypos, 6, 0, 0, False, False, 0, 0, 0, 0, 0, 0, 255)
            bu.setXVel(5 * math.sin(math.radians((i * 12))))
            bu.setYVel(5 * math.cos(math.radians((i * 12))))
            bu.setXVelSet(True)
            walls.append(bu)

        if a10xpos < xlimit/10 or a10xpos > 9*xlimit/10:
            if a10xpos < xlimit/10:
                a10xpos += xlimit/10
            else:
                a10xpos -= xlimit / 10
        else:
            a10xpos += random.randint(int(-xlimit/10), int(xlimit/10))
        if a10ypos < ylimit/20 or a10ypos > ylimit/3:
            if a10ypos < ylimit / 20:
                a10ypos += ylimit/10
            else:
                a10ypos -= ylimit/10
        else:
            a10ypos += random.randint(int(-ylimit/10), int(ylimit/10))
    if spawncounter % int(fps / 2) == 10 and spawncounter >= 0:
        r, g, b = random.randint(50, 220), random.randint(50, 220), random.randint(50, 220)
        for i in range(29):
            bu = Bullet(a10xpos, a10ypos, a10xpos, a10ypos, 6, 0, 0, False, False, 0, 0, 0, 0, 0, 0, 255)
            bu.setXVel(3.5 * math.sin(math.radians((i * 12)) + math.pi/12))
            bu.setYVel(3.5 * math.cos(math.radians((i * 12)) + math.pi/12))
            bu.setXVelSet(True)
            walls.append(bu)
    if spawncounter % int(fps / 2) == int(fps / 3) and spawncounter >= 0:
        r, g, b = random.randint(50, 220), random.randint(50, 220), random.randint(50, 220)
        for i in range(24):
            bu = Bullet(a10xpos, a10ypos, a10xpos, a10ypos, 18, 0, 0, False, False, 0, 0, 0, 0, r, g, b)
            bu.setXVel(4 * math.sin(math.radians((i * 15))))
            bu.setYVel(4 * math.cos(math.radians((i * 15))))
            bu.setXVelSet(True)
            walls.append(bu)

def Attack11(spawncounter, attackduration, walls, wall_group):
    #sets of circular shots with bursts of random shots
    global a11xpos
    global a11ypos
    if spawncounter % int(fps * 2) <= int(2 * fps / 5) and spawncounter >= 0:
        #burst of circular shots
        for i in range(90):
            bu = Bullet(a11xpos, a11ypos, a11xpos, a11ypos, 4, 0, 0, False, False, 0, 0, 0, 0, 80, 80, 80)
            bu.setXVel(7 * math.sin(math.radians((i * 4))))
            bu.setYVel(7 * math.cos(math.radians((i * 4))))
            bu.setXVelSet(True)
            walls.append(bu)

        if spawncounter % int(fps * 2) == int(fps / 5):
            #burst of random shots
            for i in range(120):
                #using xdiff = 1 to differentiate these bullets from previous ones
                bu = Bullet(a11xpos, a11ypos, a11xpos, a11ypos, 5, 0, 0, False, False, 1, 0, attackduration, 0, 255, 0, 0)
                bu.setXVel(2.5 * math.sin(math.radians((i*3))))
                bu.setYVel(2.5 * math.cos(math.radians((i*3))))
                bu.setXVelSet(True)
                walls.append(bu)
        if spawncounter % int(fps * 2) == int(2 * fps / 5):
            #change position of center
            if a11xpos < xlimit/10 or a11xpos > 9*xlimit/10:
                if a11xpos < xlimit/10:
                    a11xpos += xlimit/10
                else:
                    a11xpos -= xlimit / 10
            else:
                a11xpos += random.randint(int(-xlimit/10), int(xlimit/10))
            if a11ypos < ylimit/20 or a11ypos > ylimit/3:
                if a11ypos < ylimit / 20:
                    a11ypos += ylimit/10
                else:
                    a11ypos -= ylimit/10
            else:
                a11ypos += random.randint(int(-ylimit/10), int(ylimit/10))

def Attack12(spawncounter, attackduration, walls, wall_group):
    #circular patterns, rows of shots from side, spiral shots (see remilia's 3rd life bar spellcard)
    global a12xpos, a12ypos, a12leftx, a12lefty, a12rightx, a12righty
    global xvl, yvl, xvr, yvr
    if spawncounter % int(fps / 5) == 0 and spawncounter % int(2.4 * fps) < int(2 * fps) and spawncounter >= 0:
        for i in range(72): #circular patterns
            bu = Bullet(a12xpos, a12ypos, a12xpos, a12ypos, 6, 0, 0, False, False, 0, 0, 0, 0, 255, 165, 00)
            bu.setXVel(3.5 * math.sin(math.radians((i * 5))))
            bu.setYVel(3.5 * math.cos(math.radians((i * 5))))
            bu.setXVelSet(True)
            walls.append(bu)

    if spawncounter % fps == 0 and spawncounter % int(2 * fps) < int(0.6 * fps) and spawncounter >= 0: #velocity for side rows
        xvl = 0.85 * random.randint(3, 6)
        yvl = 0.85 * math.sqrt(50 - (xvl ** 2))
        xvr = -0.85 * random.randint(3, 6)
        yvr = 0.85 * math.sqrt(50 - (xvl ** 2))
        #print(str(xvl) + " " + str(yvl))
    if spawncounter % int(fps / 5) == 0 and spawncounter % int(2 * fps) < int(0.6 * fps) and spawncounter >= 1: #left & right rows
        xv, yv = xvl, yvl
        xv2, yv2 = xvr, yvr
        for i in range(10):
            bu = Bullet(a12leftx, ((xlimit/6) - (xlimit/30) * i) + a12lefty, a12leftx, ((xlimit/6) - (xlimit/30) * i) + a12lefty,
                        5, 0, 0, False, False, 0, 0, 0, 0, 255, 0, 0)
            bu2 = Bullet(a12rightx, ((xlimit/6) - (xlimit/30) * i) + a12righty, a12leftx, ((xlimit/6) - (xlimit/30) * i) + a12lefty,
                         5, 0, 0, False, False, 0, 0, 0, 0, 255, 0, 0)
            bu.setXVel(xv)
            bu.setYVel(yv)
            bu2.setXVel(xv2)
            bu2.setYVel(yv2)
            walls.append(bu)
            walls.append(bu2)
    if spawncounter % int(2.4 * fps) == 0 and spawncounter >= 0:
        circleRadius = 100 #radius of circle that shots spawn around
        for i in range(360):  # spiral shots
            xOffset = circleRadius * math.sin(math.radians(i))
            yOffset = circleRadius * math.cos(math.radians(i))
            if xOffset == 0:
                if yOffset < 0:
                    shotAngle = numpy.pi / 4
                elif yOffset > 0:
                    shotAngle = 3 * numpy.pi / 4
            else:
                shotAngle = numpy.arctan(yOffset / xOffset)
            bu = Bullet(a12xpos + (circleRadius * math.sin(math.radians(i * 5))), a12ypos + (circleRadius * math.cos(math.radians(i * 5))),
                        a12xpos + (circleRadius * math.sin(math.radians(i * 5))), a12ypos + (circleRadius * math.cos(math.radians(i * 5))),
                        6, 0, 0, False, True, a12xpos, a12ypos, spawncounter, 0, random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
            #xdiff, ydiff are coords of center
            #shotangle is angle from center
            #yvelset as true as a marker

            bu.setXVel(6 * math.sin(math.radians((i * 5)))) #changes rotation speed
            bu.setYVel(6 * math.cos(math.radians((i * 5))))
            bu.setYVelSet(True)
            walls.append(bu)
    if spawncounter % int(2.3 * fps) == 0 and spawncounter >= 0: #position changing for main circle attack
        if a12xpos < xlimit / 10 or a12xpos > 9 * xlimit / 10:
            if a12xpos < xlimit / 10:
                a12xpos += xlimit / 10
            else:
                a12xpos -= xlimit / 10
        else:
            a12xpos += random.randint(int(-xlimit / 10), int(xlimit / 10))
        if a12ypos < ylimit / 20 or a12ypos > ylimit / 3:
            if a12ypos < ylimit / 20:
                a12ypos += ylimit / 10
            else:
                a12ypos -= ylimit / 10
        else:
            a12ypos += random.randint(int(-ylimit / 10), int(ylimit / 10))
    """if spawncounter % 100 == 0 and spawncounter >= 0: #position changing for left shots
        print(a12lefty)
        if a12lefty > 4 * ylimit / 5 or a12lefty < ylimit / 5:
            if a12lefty > 4 * ylimit / 5:
                a12lefty -= ylimit / 5
            else:
                a12lefty += ylimit / 5
        else:
            a12lefty += random.choice([-1, 1]) * ylimit / 4"""



